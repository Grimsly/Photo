﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PhotoGrid.Visibility = Visibility.Hidden; 
            List<BitmapImage> images = HelperMethods481.AssemblyManager.GetImagesFromEmbeddedResources();
            foreach (BitmapImage image in images)
            {
                PhotoTileControl file = new PhotoTileControl();
                file.ImageContent.Source = image;
                ThumbnailGrid.Children.Add(file);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            SplashGrid.Visibility = Visibility.Hidden;
            PhotoGrid.Visibility = Visibility.Visible;
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SplashGrid.Visibility = Visibility.Visible;
            PhotoGrid.Visibility = Visibility.Hidden;
        }
    }
}
